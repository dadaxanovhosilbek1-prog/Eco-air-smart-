ECO-AIR SMART — Android loyiha manbasi
Ishlab chiquvchi: Dadaxonov Hosilbek

Bu ZIP Android ilova loyihasining manba fayllarini o'z ichiga oladi.
Hozirgi ilova demo rejimda ishlaydi: ko'rsatkichlar sun'iy namunaviy qiymatlar.
Haqiqiy CO/CO2/NOx/HC sensorlari, ESP32 bilan ishlash va real o'lchash hali ulanmagan.
Bluetooth/Wi-Fi tugmalari hozircha to'liq sensor protokoli bilan bog'lanmagan.

APK olish (telefon orqali GitHub yordamida):
1. github.com saytida hisobga kiring.
2. New repository yarating (masalan: eco-air-smart).
3. Ushbu ZIPni ochib, ichidagi barcha fayl va papkalarni repositoryga yuklang.
4. GitHub repository -> Actions bo'limiga o'ting.
5. "Build ECO-AIR SMART APK" workflow ni tanlang va Run workflow bosing.
6. Build tugagach, Actions natijasidan "ECO-AIR-SMART-debug-apk" artifactini yuklab oling.
7. ZIP ichidan app-debug.apk faylini telefonga o'rnating. Android so'rasa, brauzer/fayl menejeriga "unknown apps install" ruxsatini bering.

Eslatma: bu debug APK bo'ladi, Play Store uchun imzolangan release APK emas.
